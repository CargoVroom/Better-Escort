# Better Escort

Don't you hate it when you do an escort mission and nothing happens for the entire time the APCs are moving from the pickup to the dropoff? 

This changes the contracts so there is always a fight with the convoy is in motion. Number of enemies per contract is kept the same.

0.1.1 Added Asset Security and Protect the Mechs <--- Release Version

0.1.0 - 7/7/2019, files updated to 1.6 standard.

0.0.1 - Test version given to BloodyDoves to try in BTA3062